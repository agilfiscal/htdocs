<div class="main-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h1 class="h3 mb-4 text-gray-800">Financeiro</h1>
                
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Dashboard Financeiro</h6>
                    </div>
                    <div class="card-body">
                        <p>Bem-vindo ao módulo financeiro.</p>
                        <!-- Adicione aqui o conteúdo específico do financeiro -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> 