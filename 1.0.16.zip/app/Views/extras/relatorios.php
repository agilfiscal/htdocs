<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">
                        <i class="fas fa-chart-bar me-2"></i>
                        Relatórios
                    </h4>
                    <p class="card-subtitle text-muted">
                        Gere relatórios detalhados do sistema
                    </p>
                </div>
                <div class="card-body">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        <strong>Funcionalidade em desenvolvimento</strong><br>
                        Esta página está sendo desenvolvida e estará disponível em breve.
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> 