<?php

namespace App\Controllers;

class SuporteController extends Controller {
    public function index() {
        $this->view('suporte/index');
    }
} 