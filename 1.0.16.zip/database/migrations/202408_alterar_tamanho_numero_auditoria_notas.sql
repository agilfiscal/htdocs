-- Alterar o tamanho da coluna numero na tabela auditoria_notas
ALTER TABLE auditoria_notas MODIFY COLUMN numero VARCHAR(100); 