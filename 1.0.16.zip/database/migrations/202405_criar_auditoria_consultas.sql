CREATE TABLE IF NOT EXISTS auditoria_consultas (
    empresa_id INT PRIMARY KEY,
    ultima_consulta DATETIME
); 