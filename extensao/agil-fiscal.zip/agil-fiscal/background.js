let chaveGlobal = null;
let tabIdOpen = null;
let windowIdOpen = null;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.tipo === "AbrirConsulta") {
    chaveGlobal = request.chave;
    chrome.windows.create({
      url: request.url,
      type: "popup",
      width: 1024,
      height: 800,
      focused: true
    }, (window) => {
      tabIdOpen = window.tabs[0].id;
      windowIdOpen = window.id;
    });
    sendResponse(true);
  } else if (request.tipo === "GetChave") {
    sendResponse({ chave: chaveGlobal });
    return true;
  }
});

chrome.windows.onRemoved.addListener((windowId) => {
  if (windowId === windowIdOpen) {
    windowIdOpen = null;
    tabIdOpen = null;
  }
});