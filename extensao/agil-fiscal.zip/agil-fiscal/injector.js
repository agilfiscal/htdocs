chrome.runtime.sendMessage({ tipo: "GetChave" }, (response) => {
    const chave = response.chave;
    if (chave && chave.length === 44) {
      const input = document.querySelector("#ctl00_ContentPlaceHolder1_txtChaveAcessoResumo");
      if (input) {
        input.value = chave;
        input.dispatchEvent(new Event('input'));
      }
    }
  });