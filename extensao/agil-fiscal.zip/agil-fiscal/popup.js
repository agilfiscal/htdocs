document.getElementById("consultar").onclick = () => {
    const chave = document.getElementById("chave").value.trim();
    if (chave.length === 44) {
      chrome.runtime.sendMessage({ tipo: "AbrirConsulta", chave: chave, url: "https://www.nfe.fazenda.gov.br/portal/consultaRecaptcha.aspx?tipoConsulta=resumo" });
    } else {
      alert("Chave inválida. Deve conter 44 dígitos.");
    }
  };